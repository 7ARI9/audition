// src/assets/index.js
export const ASSETS = {
  logo: "/img/logo.png",

  // صور الأقسام
  hero: "/img/hero.jpg",
  about: "/img/about.jpg",
  tier1: "/img/tier1.jpg",
  tier2: "/img/tier2.jpg",
  tier3: "/img/tier3.jpg",
  contact: "/img/contact.jpg",

  // خريطة Google
  map: "https://www.google.com/maps?q=13+rue+Fran%C3%A7ois+Mousis+Tarbes&output=embed",
};
