// src/sections/TierPayant.jsx
import React, { useRef } from "react";
import { motion } from "framer-motion";
import { Stethoscope, Headset, Wrench, ShieldCheck, Sparkles } from "lucide-react";
import { ASSETS } from "../assets";

const ease = [0.22, 1, 0.36, 1];
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease } },
};
const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};

/* خلفية فاتحة حيّة متناسقة */
function LightAuroraBg() {
  return (
    <>
      <div
        className="absolute inset-0 -z-50"
        style={{ background: "linear-gradient(135deg,#ffffff 0%,#f8fbff 50%,#f0f7ff 100%)" }}
        aria-hidden
      />
      <motion.div
        className="absolute inset-0 -z-40 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(15,23,42,.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(15,23,42,.25) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          backgroundPosition: "0px 0px",
        }}
        animate={{ backgroundPosition: ["0px 0px", "28px 28px"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -top-32 -left-24 h-[26rem] w-[26rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(59,130,246,0.18), transparent 60%)" }}
        animate={{ x: [0, 24, -8, 0], y: [0, -18, 12, 0], scale: [1, 1.06, 0.98, 1] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -bottom-28 -right-20 h-[26rem] w-[26rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(56,189,248,0.16), transparent 60%)" }}
        animate={{ x: [0, -20, 16, 0], y: [0, 16, -12, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
    </>
  );
}

/* بطاقة موديولار مع تحكّم في تموضع الصورة ونسبتها */
function FeatureCard({ icon, title, desc, img, chip, delay = 0, pos, tilt, zoom }) {
  const cardRef = useRef(null);

  return (
    <motion.div
      ref={cardRef}
      variants={fadeUp}
      transition={{ ...fadeUp.show.transition, delay }}
      whileHover={{ y: -6 }}
      className="group relative rounded-3xl p-[2px]"
      style={{
        background:
          "linear-gradient(135deg, rgba(59,130,246,.35), rgba(56,189,248,.35), rgba(99,102,241,.35))",
      }}
    >
      <div className="relative rounded-[22px] bg-white/70 backdrop-blur-xl ring-1 ring-slate-200 overflow-hidden">
        {/* شارة أعلى يمين */}
        {chip && (
          <div className="absolute right-4 top-4 z-10 inline-flex items-center gap-1 rounded-full bg-white/90 px-3 py-1 text-xs font-semibold text-slate-700 ring-1 ring-slate-200">
            <ShieldCheck className="h-3.5 w-3.5 text-emerald-500" />
            {chip}
          </div>
        )}

        <div className="flex flex-col items-center px-5 pt-14 pb-4">
          {/* رأس البطاقة */}
          <div className="mb-4 flex w-full items-start gap-3">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-50 to-cyan-50 ring-1 ring-slate-200">
              {icon}
            </div>
            <div className="min-w-0">
              <h4 className="text-xl font-extrabold tracking-tight text-slate-900">{title}</h4>
              <p className="text-sm text-slate-600">{desc}</p>
            </div>
          </div>

          {/* صورة بنسبة أبعاد موحّدة + تحكّم بموضعها */}
          <div className="relative -mt-2 mb-5 w-full rounded-[26px] overflow-hidden">
            <div className="relative w-full aspect-[4/3]">
              <motion.img
                src={img}
                alt={title}
                className="absolute inset-0 h-full w-full object-cover"
                style={{ objectPosition: pos || "50% 50%" }}
                initial={{ rotate: typeof tilt === "number" ? tilt : -1, scale: zoom || 1.02 }}
                whileHover={{ scale: 1.05, rotate: 0 }}
                transition={{ duration: 0.6, ease }}
              />
            </div>
            <div className="pointer-events-none absolute inset-0 rounded-[26px] ring-1 ring-slate-200/70" />
            <div className="pointer-events-none absolute inset-x-6 bottom-3 h-10 rounded-full bg-gradient-to-r from-sky-200/45 via-blue-200/45 to-indigo-200/45 blur-2xl" />
          </div>

          {/* أكشن */}
          <div className="mt-1 flex w-full items-center justify-between">
            <div className="text-xs text-slate-500">Accompagnement personnalisé</div>
            <motion.a
              href="#contact"
              whileHover={{ y: -1, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-xl border border-slate-200 px-3 py-2 text-sm font-semibold text-slate-900"
              style={{
                background:
                  "linear-gradient(90deg, rgba(239,246,255,1), rgba(240,249,255,1), rgba(238,242,255,1))",
                backgroundSize: "200% 200%",
              }}
              animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
            >
              En savoir plus
              <Sparkles className="h-4 w-4 text-blue-500 opacity-80 transition-transform group-hover:rotate-12" />
            </motion.a>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

export default function TierPayant() {
  const data = [
    {
      img: ASSETS.tier1,
      title: "Dépistage",
      desc: "Test auditif rapide & précis",
      icon: <Stethoscope className="h-5 w-5 text-blue-600" />,
      chip: "100% Santé",
      pos: "50% 50%",
      tilt: -1,
      zoom: 1.02,
    },
    {
      img: ASSETS.tier2,
      title: "Appareillage",
      desc: "Solutions discrètes & connectées",
      icon: <Headset className="h-5 w-5 text-indigo-600" />,
      chip: "Essai 30j",
      /* ✅ ضبط تموضع الصورة الوسطى */
      pos: "60% 50%", // غيّرها حسب ما يلزم (مثلاً 65% 50% أو 55% 45%)
      tilt: 0,
      zoom: 1.02,
    },
    {
      img: ASSETS.tier3,
      title: "Suivi & SAV",
      desc: "Réglages, entretien & SAV",
      icon: <Wrench className="h-5 w-5 text-cyan-600" />,
      chip: "Priorité Client",
      pos: "50% 50%",
      tilt: -1,
      zoom: 1.02,
    },
  ];

  return (
    <section className="relative overflow-hidden bg-transparent py-16 md:py-20 text-slate-900">
      <LightAuroraBg />

      <div className="relative mx-auto max-w-7xl px-4">
        {/* العنوان */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
          className="mb-10 md:mb-14"
        >
          <motion.p variants={fadeUp} className="mb-2 text-sm font-semibold tracking-wide text-sky-600">
            AVANTAGES & PRISE EN CHARGE
          </motion.p>
          <motion.h3 variants={fadeUp} className="text-4xl font-black leading-tight tracking-tight md:text-5xl">
            100% SANTÉ / TIERS-PAYANT
          </motion.h3>
          <motion.div
            variants={fadeUp}
            className="mt-2 h-[6px] w-40 rounded-full"
            style={{ background: "linear-gradient(90deg,#2563eb,#38bdf8,#6366f1)" }}
          />
        </motion.div>

        {/* البطاقات */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="grid gap-6 md:grid-cols-3"
        >
          {data.map((item, i) => (
            <FeatureCard key={item.title} delay={i * 0.08} {...item} />
          ))}
        </motion.div>
      </div>

      {/* ملصقات خفيفة */}
      <motion.div
        className="pointer-events-none absolute left-6 top-8 hidden rounded-full bg-white/70 px-3 py-1.5 text-xs font-semibold text-slate-700 ring-1 ring-slate-200 md:block"
        animate={{ y: [-8, 6, -8] }}
        transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
      >
        Prise en charge
      </motion.div>
      <motion.div
        className="pointer-events-none absolute bottom-10 right-6 hidden rounded-full bg-white/70 px-3 py-1.5 text-xs font-semibold text-slate-700 ring-1 ring-slate-200 md:block"
        animate={{ y: [6, -6, 6] }}
        transition={{ duration: 6.5, repeat: Infinity, ease: "easeInOut" }}
      >
        Sans avance de frais
      </motion.div>
    </section>
  );
}
