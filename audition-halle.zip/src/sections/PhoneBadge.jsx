// src/sections/PhoneBadge.jsx
import React from "react";
import { motion } from "framer-motion";
import { Phone } from "lucide-react";

export default function PhoneBadge({ className = "" }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
      className={`flex items-center gap-2 rounded-xl bg-indigo-900/95 px-3 py-2 text-white shadow-lg ${className}`}
    >
      <motion.span
        className="inline-flex h-4 w-4 items-center justify-center"
        animate={{ scale: [1, 1.15, 1] }}
        transition={{ repeat: Infinity, duration: 1.6, ease: "easeInOut" }}
      >
        <Phone className="h-4 w-4" />
      </motion.span>
      <span className="text-sm font-semibold">05 62 36 52 76</span>
    </motion.div>
  );
}
