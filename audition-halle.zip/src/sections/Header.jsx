// src/sections/Header.jsx
import React from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Phone } from "lucide-react";
import { ASSETS } from "../assets";

const NAV = [
  { label: "Accueil", href: "#accueil" },
  { label: "Services", href: "#services" },
  { label: "À Propos", href: "#apropos" },
  { label: "Contact", href: "#contact" },
];

export default function Header() {
  const { scrollY } = useScroll();
  const bg = useTransform(
    scrollY,
    [0, 120],
    ["rgba(255,255,255,0.7)", "rgba(255,255,255,0.95)"]
  );
  const shadow = useTransform(
    scrollY,
    [0, 120],
    ["0 0 0 rgba(0,0,0,0)", "0 10px 30px rgba(2,6,23,0.08)"]
  );

  return (
    <motion.header
      style={{ background: bg, boxShadow: shadow, backdropFilter: "blur(10px)" }}
      className="sticky top-0 z-40 border-b border-slate-200"
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
        {/* Logo */}
        <a href="#accueil" className="flex items-center gap-3 no-underline">
          <img src={ASSETS.logo} alt="Logo" className="h-9" />
        </a>

        {/* Nav */}
        <nav className="hidden items-center gap-8 md:flex">
          {NAV.map((n) => (
            <a
              key={n.label}
              href={n.href}
              className="no-underline text-sm font-medium text-slate-700 hover:text-blue-700"
            >
              {n.label}
            </a>
          ))}
        </nav>

        {/* Right side */}
        <div className="flex items-center gap-4">
          {/* الهاتف يمين Contacter */}
          <a
            href="tel:+33562365276"
            className="hidden sm:flex items-center gap-2 no-underline text-slate-800 hover:text-blue-700"
          >
            <Phone className="h-4 w-4" />
            <span className="font-semibold tracking-wide">05 62 36 52 76</span>
          </a>

          <motion.a
            whileHover={{ scale: 1.03, y: -1 }}
            whileTap={{ scale: 0.98 }}
            href="#contact"
            className="no-underline rounded-2xl bg-blue-700 px-4 py-2 text-sm font-medium text-white shadow hover:bg-blue-800"
          >
            Contacter
          </motion.a>
        </div>
      </div>
    </motion.header>
  );
}
