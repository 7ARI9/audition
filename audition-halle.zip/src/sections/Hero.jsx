// src/sections/Hero.jsx
import React, { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { ChevronRight, Headset, Sparkles, Star, Phone } from "lucide-react";
import PhoneBadge from "./PhoneBadge"; // keep your small badge for mobile overlay if you want
import { ASSETS } from "../assets";

// motion presets
const ease = [0.22, 1, 0.36, 1];
const fadeUp = { hidden: { opacity: 0, y: 24 }, show: { opacity: 1, y: 0, transition: { duration: 0.6, ease } } };
const fade = { hidden: { opacity: 0 }, show: { opacity: 1, transition: { duration: 0.6, ease } } };
const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } } };

// tiny helpers
function FloatingSticker({ className = "", children, duration = 6, delay = 0 }) {
  return (
    <motion.div
      className={className}
      initial={{ y: 0 }}
      animate={{ y: [-6, 6, -6] }}
      transition={{ duration, repeat: Infinity, ease: "easeInOut", delay }}
    >
      {children}
    </motion.div>
  );
}

// BIG phone banner (above heading)
function PhoneBanner() {
  return (
    <motion.a
      href="tel:+33562365276"
      whileHover={{ y: -2, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      className="group relative inline-flex items-center gap-3 rounded-2xl px-5 py-3 text-white"
      style={{
        background:
          "linear-gradient(90deg, rgba(37,99,235,1), rgba(79,70,229,1), rgba(124,58,237,1))",
        boxShadow: "0 20px 40px rgba(67,56,202,0.15)",
      }}
    >
      {/* animated ring glow */}
      <span className="pointer-events-none absolute -inset-1 rounded-3xl opacity-60 blur-md"
            style={{ background: "radial-gradient(60% 60% at 50% 50%, rgba(99,102,241,0.35), transparent)" }} />
      <span className="relative z-10 flex h-8 w-8 items-center justify-center rounded-xl bg-white/15 backdrop-blur">
        <Phone className="h-4 w-4" />
      </span>
      <span className="relative z-10 text-xl font-extrabold tracking-wide">
        05 62 36 52 76
      </span>
      {/* shimmer on hover */}
      <span className="pointer-events-none absolute inset-0 overflow-hidden rounded-2xl">
        <motion.span
          className="absolute left-[-30%] top-0 h-full w-1/3 -skew-x-12 bg-white/30 opacity-0 group-hover:opacity-100"
          animate={{ left: ["-30%", "120%"] }}
          transition={{ repeat: Infinity, duration: 1.8, ease: "easeOut" }}
        />
      </span>
    </motion.a>
  );
}

export default function Hero() {
  const imgRef = useRef(null);
  const sectionRef = useRef(null);

  const { scrollYProgress } = useScroll({ target: imgRef, offset: ["start end", "end start"] });
  const parallaxY = useTransform(scrollYProgress, [0, 1], ["-6%", "6%"]);

  const handleMouseMove = (e) => {
    const el = sectionRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty("--mx", `${((e.clientX - r.left) / r.width) * 100}%`);
    el.style.setProperty("--my", `${((e.clientY - r.top) / r.height) * 100}%`);
  };
  const handleMouseLeave = () => {
    const el = sectionRef.current;
    if (!el) return;
    el.style.setProperty("--mx", `55%`);
    el.style.setProperty("--my", `40%`);
  };

  return (
    <section
      id="accueil"
      ref={sectionRef}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className="relative overflow-hidden"
      style={{ ["--mx"]: "55%", ["--my"]: "40%" }}
    >
      {/* ===== ALIVE BACKGROUND ===== */}
      {/* base gradient */}
      <div
        className="absolute inset-0 -z-50"
        style={{ background: "linear-gradient(135deg,#F7FBFF 0%,#EEF2FF 40%,#F5F3FF 100%)" }}
      />
      {/* soft vignette */}
      <div
        className="pointer-events-none absolute inset-0 -z-40"
        style={{ background: "radial-gradient(1100px 600px at 50% 80%, rgba(2,6,23,0.10), transparent 60%)" }}
      />
      {/* animated grid */}
      <motion.div
        className="absolute inset-0 -z-30 opacity-[0.16]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(15,23,42,.06) 1px, transparent 1px), linear-gradient(to bottom, rgba(15,23,42,.06) 1px, transparent 1px)",
          backgroundSize: "22px 22px",
          backgroundPosition: "0px 0px",
        }}
        animate={{ backgroundPosition: ["0px 0px", "22px 22px"] }}
        transition={{ duration: 26, repeat: Infinity, ease: "linear" }}
      />
      {/* aurora blobs (more color) */}
      <motion.div
        className="pointer-events-none absolute -top-40 -left-40 h-[30rem] w-[30rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(56,189,248,0.35), rgba(56,189,248,0.0) 60%)", mixBlendMode: "multiply" }}
        animate={{ x: [0, 40, -20, 0], y: [0, -30, 10, 0], scale: [1, 1.08, 0.96, 1] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="pointer-events-none absolute -bottom-40 -right-24 h-[32rem] w-[32rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(79,70,229,0.28), rgba(79,70,229,0) 60%)", mixBlendMode: "multiply" }}
        animate={{ x: [0, -35, 25, 0], y: [0, 20, -18, 0], scale: [1, 0.95, 1.06, 1] }}
        transition={{ duration: 30, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.div
        className="pointer-events-none absolute top-[20%] left-[55%] h-[24rem] w-[24rem] -translate-x-1/2 rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(168,85,247,0.28), rgba(168,85,247,0) 60%)", mixBlendMode: "multiply" }}
        animate={{ x: [0, 24, -16, 0], y: [0, -16, 22, 0] }}
        transition={{ duration: 32, repeat: Infinity, ease: "easeInOut" }}
      />
      {/* mouse spotlight */}
      <div
        className="pointer-events-none absolute inset-0 -z-20"
        style={{ background: "radial-gradient(700px circle at var(--mx) var(--my), rgba(37,99,235,0.12), transparent 52%)" }}
      />

      {/* ===== CONTENT ===== */}
      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-4 py-16 md:grid-cols-2 md:py-24">
        {/* LEFT */}
        <motion.div variants={stagger} initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.3 }}>
          {/* phone above heading */}
          <div className="mb-6">
            <PhoneBanner />
          </div>

          {/* ALL CAPS, tighter tracking, animated underline/highlight */}
          <motion.h1
            variants={fadeUp}
            className="mb-5 text-[38px] font-black tracking-[-0.02em] leading-[1.05] text-slate-900 md:text-6xl uppercase"
          >
            <span className="relative">
              <span className="relative z-10">SOLUTIONS</span>
              {/* soft highlight behind first word */}
              <motion.span
                aria-hidden
                className="absolute -bottom-1 left-0 right-0 z-0 h-3 rounded-full"
                style={{
                  background:
                    "linear-gradient(90deg, rgba(59,130,246,0.35), rgba(129,140,248,0.35), rgba(167,139,250,0.35))",
                  filter: "blur(2px)",
                }}
                initial={{ scaleX: 0, opacity: 0 }}
                whileInView={{ scaleX: 1, opacity: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.8, ease }}
              />
            </span>{" "}
            AUDITIVES{" "}
            <span className="relative inline-block">
              <span className="relative z-10 bg-gradient-to-r from-blue-700 via-indigo-700 to-violet-700 bg-clip-text text-transparent">
                INNOVANTES
              </span>
              {/* animated underline under keyword */}
              <motion.span
                aria-hidden
                className="absolute -bottom-1 left-0 right-0 mx-auto h-[6px] w-full max-w-[92%] rounded-full"
                style={{
                  background:
                    "linear-gradient(90deg, rgba(59,130,246,0.95), rgba(99,102,241,0.95), rgba(139,92,246,0.95))",
                }}
                initial={{ scaleX: 0 }}
                whileInView={{ scaleX: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, ease }}
              />
            </span>
          </motion.h1>

          {/* copy with bold & highlights */}
          <motion.p variants={fade} className="mb-10 max-w-xl text-lg text-slate-700">
            <strong className="font-semibold text-slate-900">DÉPISTAGE GRATUIT</strong>, appareillage{" "}
            <span className="relative font-semibold">
              PERSONNALISÉ
              <span className="absolute -bottom-0.5 left-0 right-0 mx-auto h-2 w-[94%] rounded bg-blue-200/60 blur-[2px]" />
            </span>{" "}
            et <strong className="font-semibold text-slate-900">SUIVI CONTINU</strong> — une expérience d’écoute plus
            <span className="font-semibold text-slate-900"> NETTE</span> et plus <span className="font-semibold text-slate-900">NATURELLE</span>.
          </motion.p>

          {/* buttons (animated backgrounds) */}
          <motion.div variants={fade} className="relative flex flex-wrap items-center gap-3">
            <div className="pointer-events-none absolute -inset-x-6 -inset-y-3 rounded-3xl bg-gradient-to-r from-blue-500/10 to-fuchsia-500/10 blur-xl" />
            {/* primary */}
            <motion.a
              whileHover={{ y: -1, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href="#services"
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-2xl border border-white/10 px-5 py-3 font-semibold text-white shadow-lg shadow-indigo-500/20"
              style={{
                background:
                  "linear-gradient(90deg, rgba(37,99,235,1), rgba(67,56,202,1), rgba(124,58,237,1))",
                backgroundSize: "200% 200%",
              }}
              animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
              transition={{ duration: 5.5, repeat: Infinity, ease: "linear" }}
            >
              <span>VOIR LES SERVICES</span>
              <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              <span className="pointer-events-none absolute inset-0">
                <motion.span
                  className="absolute left-[-30%] top-0 h-full w-1/3 -skew-x-12 bg-white/30 opacity-0 group-hover:opacity-100"
                  animate={{ left: ["-30%", "120%"] }}
                  transition={{ repeat: Infinity, duration: 1.8, ease: "easeOut" }}
                />
              </span>
            </motion.a>
            {/* secondary */}
            <motion.a
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
              href="#contact"
              className="relative rounded-2xl p-[2px]"
              animate={{ backgroundPosition: ["0% 50%", "100% 50%"] }}
              transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
              style={{
                background:
                  "linear-gradient(90deg, rgba(99,102,241,0.5), rgba(139,92,246,0.5), rgba(56,189,248,0.5))",
                backgroundSize: "200% 200%",
              }}
            >
              <span className="inline-flex items-center gap-2 rounded-[14px] border border-slate-200 bg-white/85 px-5 py-3 font-semibold text-slate-900 backdrop-blur hover:bg-white">
                PRENDRE RDV
              </span>
            </motion.a>
          </motion.div>
        </motion.div>

        {/* RIGHT: bubble / 3D twist + stickers */}
        <div className="relative">
          <motion.div
            className="relative rounded-[32px] border border-white/50 bg-white/70 p-2 shadow-2xl backdrop-blur"
            initial={{ boxShadow: "0 30px 60px rgba(31,71,255,0.08)" }}
            whileHover={{ boxShadow: "0 40px 80px rgba(31,71,255,0.14)" }}
            transition={{ duration: 0.4, ease }}
            style={{ transformStyle: "preserve-3d", perspective: 1000 }}
          >
            <div className="overflow-hidden rounded-[28px] shadow-2xl will-change-transform">
              {/* 3D twist: push left side a bit for depth */}
              <motion.img
                ref={imgRef}
                src={ASSETS.hero}
                alt="Accueil"
                style={{ y: parallaxY }}
                className="block h-auto w-full"
                initial={{ rotateY: -10, rotateX: 2, skewX: -2 }}
                whileHover={{ rotateY: -6, skewX: -1, scale: 1.02 }}
                transition={{ duration: 0.6, ease }}
              />
            </div>
            {/* inner glow */}
            <div className="pointer-events-none absolute inset-2 rounded-[26px] bg-gradient-to-tr from-indigo-500/10 via-fuchsia-500/10 to-cyan-400/10 blur-xl" />
          </motion.div>

          {/* floating stickers */}
          <FloatingSticker className="absolute -top-5 -left-4 hidden rounded-full bg-white/90 px-3 py-2 text-xs font-semibold shadow-md md:flex">
            <Sparkles className="mr-1 h-4 w-4 text-indigo-600" /> 100% Santé
          </FloatingSticker>
          <FloatingSticker className="absolute -bottom-5 left-8 hidden rounded-full bg-white/90 px-3 py-2 text-xs font-semibold shadow-md md:flex" delay={1.2}>
            <Headset className="mr-1 h-4 w-4 text-violet-600" /> Essai 30j
          </FloatingSticker>
          <FloatingSticker className="absolute -top-6 right-2 hidden rounded-full bg-white/90 px-3 py-2 text-xs font-semibold shadow-md md:flex" delay={0.6}>
            <Star className="mr-1 h-4 w-4 text-amber-500" /> Suivi Pro
          </FloatingSticker>
          {/* extra sticker */}
          <FloatingSticker className="absolute bottom-10 -right-6 hidden rounded-full bg-white/90 px-3 py-2 text-xs font-semibold shadow-md md:flex" delay={0.9}>
            <Sparkles className="mr-1 h-4 w-4 text-cyan-600" /> Discret & Connecté
          </FloatingSticker>

          {/* small phone badge on mobile (optional) */}
          <PhoneBadge className="absolute -bottom-4 left-6 md:hidden" />
        </div>
      </div>
    </section>
  );
}
