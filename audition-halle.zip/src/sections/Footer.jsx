// src/sections/Footer.jsx
import React from "react";
import { Phone, Clock } from "lucide-react";

const ASSETS = {
  logo: "/img/logo.png",
  map: "https://www.google.com/maps?q=13+rue+Fran%C3%A7ois+Mousis+Tarbes&output=embed",
};

export default function Footer() {
  const HOURS = [
    ["LUNDI", "9h–12h / 14h–18h"],
    ["MARDI", "9h–12h / 14h–18h"],
    ["MERCREDI", "9h–12h / 14h–18h"],
    ["JEUDI", "9h–12h / 14h–18h"],
    ["VENDREDI", "9h–12h / 14h–18h"],
    ["SAMEDI", "Fermé"],
  ];

  return (
    <footer className="relative overflow-hidden bg-gradient-to-br from-slate-900 to-indigo-950 text-slate-100 py-14 md:py-16">
      {/* لمسات ضبابية */}
      <div className="pointer-events-none absolute -top-20 -right-20 h-56 w-56 rounded-full bg-blue-500/20 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-20 -left-20 h-56 w-56 rounded-full bg-indigo-500/20 blur-3xl" />

      <div className="relative mx-auto max-w-7xl px-4">
        <div className="grid items-start gap-8 md:gap-10 md:grid-cols-3">
          {/* عمود 1 */}
          <div>
            <img src={ASSETS.logo} alt="Logo" className="h-9 brightness-110" />
            <p className="mt-3 max-w-sm text-[15px] md:text-base leading-relaxed text-slate-300">
              Centre d'audition – dépistage, appareillage et suivi.
              Technologies performantes et connectées.
            </p>
            <div className="mt-4 flex items-center gap-2.5 text-slate-200">
              <Phone className="h-5 w-5" />
              <a
                href="tel:+33562365276"
                className="no-underline text-[15px] md:text-base text-slate-200 hover:text-white"
              >
                05 62 36 52 76
              </a>
            </div>
          </div>

          {/* عمود 2: Horaires */}
          <div>
            <h4 className="mb-3 text-lg md:text-xl font-semibold tracking-wide text-white">
              Horaires d'ouverture
            </h4>
            <div className="overflow-x-hidden">
              <ul className="tabular-nums text-[13px] sm:text-[14px] md:text-base divide-y divide-white/10">
                {HOURS.map(([day, hours]) => (
                  <li
                    key={day}
                    className="flex items-baseline gap-1.5 py-1.5 pr-3 min-w-0"
                  >
                    <span className="w-20 sm:w-24 md:w-28 shrink-0 tracking-tight text-slate-200 whitespace-nowrap">
                      {day}
                    </span>
                    <span
                      className={`flex-1 min-w-0 whitespace-nowrap tracking-tight ${
                        hours === "Fermé" ? "text-rose-200" : "text-slate-300"
                      }`}
                    >
                      {hours}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* عمود 3: Map */}
          <div>
            <h4 className="mb-3 text-lg md:text-xl font-semibold tracking-wide text-white">
              Nous trouver
            </h4>
            <div className="overflow-hidden rounded-2xl ring-1 ring-white/20 shadow-inner">
              <iframe
                title="map"
                src={ASSETS.map}
                className="w-full h-[200px] md:h-[260px]"
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              />
            </div>
          </div>
        </div>

        <div className="mt-10 pt-5 text-center text-xs md:text-[13px] text-slate-400 border-t border-white/10">
          © {new Date().getFullYear()} SeekLient. Tous droits réservés.
        </div>
      </div>
    </footer>
  );
}
