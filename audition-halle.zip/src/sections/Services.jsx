// src/sections/Services.jsx
import React from "react";
import { motion } from "framer-motion";
import { ChevronRight, Sparkles, Stethoscope, Microscope, Headset } from "lucide-react";

/* البيانات: نمرّر المرجع نفسه للأيقونة لتوحيد التنسيق */
const SERVICES = [
  { Icon: Stethoscope, title: "Tiers payant",       desc: "Prise en charge immédiate sans avance de frais." },
  { Icon: Microscope,  title: "Dépistage gratuit",  desc: "Test auditif rapide et sans engagement." },
  { Icon: Headset,     title: "Essai d'appareil",   desc: "1 mois d'essai pour évaluer le bénéfice au quotidien." },
];

/* Variants مثل TierPayant */
const ease = [0.22, 1, 0.36, 1];
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show:   { opacity: 1, y: 0, transition: { duration: 0.6, ease } },
};
const stagger = { hidden: {}, show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } } };

/* نفس الخلفية الحيّة المستخدمة في TierPayant */
function LightAuroraBg() {
  return (
    <>
      <div
        className="absolute inset-0 -z-50"
        style={{ background: "linear-gradient(135deg,#ffffff 0%,#f8fbff 50%,#f0f7ff 100%)" }}
        aria-hidden
      />
      <motion.div
        className="absolute inset-0 -z-40 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(15,23,42,.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(15,23,42,.25) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          backgroundPosition: "0px 0px",
        }}
        animate={{ backgroundPosition: ["0px 0px", "28px 28px"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -top-24 -left-20 h-[22rem] w-[22rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(59,130,246,0.18), transparent 60%)" }}
        animate={{ x: [0, 18, -8, 0], y: [0, -10, 8, 0], scale: [1, 1.04, 0.98, 1] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -bottom-24 -right-20 h-[22rem] w-[22rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(56,189,248,0.16), transparent 60%)" }}
        animate={{ x: [0, -14, 12, 0], y: [0, 10, -10, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
    </>
  );
}

/* كبسولة أيقونة — موحّدة وبدون أي ظل */
/* كبسولة أيقونة — موحّدة 100% لكل البطاقات */
function IconWrap({ Icon }) {
  return (
    <div className="shrink-0 grid place-items-center h-12 w-12 rounded-full ring-1 ring-slate-200 bg-white">
      <div className="grid place-items-center h-10 w-10 rounded-full bg-gradient-to-tr from-blue-50 to-cyan-50 ring-1 ring-slate-200">
        {/* توحيد السُمك والمقاس للأيقونة نفسها */}
        <Icon className="h-5 w-5 text-blue-600" strokeWidth={2.25} />
      </div>
    </div>
  );
}


export default function Services() {
  return (
    <section id="services" className="relative overflow-hidden py-16 md:py-20">
      <LightAuroraBg />

      <div className="mx-auto max-w-7xl px-4">
        {/* عنوان مثل TierPayant */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="mb-8 md:mb-12"
        >
          <motion.p variants={fadeUp} className="mb-2 text-sm font-semibold tracking-wide text-sky-600">
            PRESTATIONS
          </motion.p>
          <motion.h2
            variants={fadeUp}
            className="relative text-4xl font-black leading-tight tracking-tight text-slate-900 md:text-5xl"
          >
            NOS SERVICES & PRESTATIONS
            <motion.span
              className="absolute -bottom-1 left-0 block h-2 w-44 rounded-full"
              style={{ background: "linear-gradient(90deg,#2563eb,#38bdf8,#6366f1)" }}
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease }}
            />
          </motion.h2>
        </motion.div>

        {/* بطاقات بنفس ستايل TierPayant (إطار جريدينت + بطاقة بيضاء بخاتم) */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3"
        >
          {SERVICES.map(({ Icon, title, desc }) => (
            <motion.div
              key={title}
              variants={fadeUp}
              whileHover={{ y: -4, rotateX: -1, rotateY: 1 }}
              transition={{ type: "spring", stiffness: 220, damping: 18 }}
              className="group relative rounded-3xl p-[1.5px]"
              style={{
                background:
                  "linear-gradient(135deg, rgba(59,130,246,.35), rgba(56,189,248,.35), rgba(99,102,241,.35))",
              }}
            >
              <div className="relative rounded-[22px] bg-white/90 backdrop-blur-sm ring-1 ring-slate-200">
                <div className="p-6">
                  {/* رأس البطاقة */}
                  <div className="mb-4 flex items-center gap-3">
                    <IconWrap Icon={Icon} />
                    <div className="min-w-0">
                      <h3 className="text-xl font-extrabold text-slate-900">{title}</h3>
                      <p className="text-sm text-slate-600">{desc}</p>
                    </div>
                  </div>

                  <div className="my-4 h-px w-full bg-gradient-to-r from-transparent via-slate-200 to-transparent" />

                  {/* زرّ أكشن بنفس ستايل TierPayant */}
                  <motion.a
                    href="#contact"
                    whileHover={{ y: -1, scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="group relative inline-flex items-center gap-2 overflow-hidden rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold text-slate-900"
                    style={{
                      background:
                        "linear-gradient(90deg, rgba(239,246,255,1), rgba(240,249,255,1), rgba(238,242,255,1))",
                      backgroundSize: "200% 200%",
                    }}
                    animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
                    transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                  >
                    En savoir plus
                    <Sparkles className="h-4 w-4 text-blue-500 opacity-80 transition-transform group-hover:rotate-12" />
                    <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </motion.a>
                </div>
              </div>
              {/* لا يوجد أي ظلّ إضافي تحت الأيقونات أو الكرت */}
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
