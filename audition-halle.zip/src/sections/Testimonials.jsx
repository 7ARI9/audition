// src/sections/Testimonials.jsx
import React, { useMemo, useEffect } from "react";
import { motion, useAnimation } from "framer-motion";
import { CircleUserRound } from "lucide-react";

const TESTIMONIALS = [
  { name: "Celia R.", text: "Service rapide et pro. J'entends mieux au téléphone et à la TV." },
  { name: "Mehdi D.", text: "Explications claires, suivi sérieux. Appareillage discret." },
  { name: "Sarah G.", text: "Accueil attentionné, prise en charge 100% santé. Je recommande !" },
  { name: "Zorah B.", text: "Très satisfaite du dépistage gratuit et de l'essai d'un mois." },
  { name: "Yanis T.", text: "Accueil top, bons conseils, appareils discrets." },
  { name: "Lina M.", text: "Suivi sérieux et résultats concrets." },
];

/* Variants simples */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] } },
};

export default function Testimonials() {
  const list = useMemo(() => [...TESTIMONIALS, ...TESTIMONIALS], []);
  const controls = useAnimation();

  useEffect(() => {
    controls.start({
      x: ["0%", "-50%"],
      transition: { duration: 20, ease: "linear", repeat: Infinity },
    });
  }, [controls]);

  return (
    <section className="bg-white py-16 md:py-20 overflow-hidden">
      <div className="mx-auto max-w-7xl px-4">
        <motion.p
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="mb-2 text-sm font-semibold text-blue-700"
        >
          VOS RETOURS
        </motion.p>
        <motion.h3
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="mb-8 text-4xl font-extrabold text-slate-900 md:text-5xl"
        >
          Avis Clients
        </motion.h3>

        {/* Slider horizontal auto défilant */}
        <div className="relative group">
          <motion.div
            className="flex gap-6"
            animate={controls}
            onMouseEnter={() => controls.stop()}
            onMouseLeave={() =>
              controls.start({
                x: ["0%", "-50%"],
                transition: { duration: 20, ease: "linear", repeat: Infinity },
              })
            }
          >
            {list.map((t, i) => (
              <motion.div
                key={i}
                whileHover={{ y: -4 }}
                className="min-w-[280px] rounded-2xl border border-slate-200 bg-white p-6 shadow-sm"
              >
                <div className="mb-3 flex items-center gap-2 text-slate-700">
                  <CircleUserRound className="h-5 w-5" />
                  <span className="text-sm font-semibold">{t.name}</span>
                </div>
                <p className="text-slate-600">{t.text}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Fading edges */}
          <div className="pointer-events-none absolute inset-y-0 left-0 w-24 bg-gradient-to-r from-white to-transparent" />
          <div className="pointer-events-none absolute inset-y-0 right-0 w-24 bg-gradient-to-l from-white to-transparent" />
        </div>
      </div>
    </section>
  );
}
