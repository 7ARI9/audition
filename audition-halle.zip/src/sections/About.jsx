// src/sections/About.jsx
import React from "react";
import { motion } from "framer-motion";
import { Check } from "lucide-react";
import PhoneBadge from "./PhoneBadge";
import { ASSETS } from "../assets";

// Variants
const ease = [0.22, 1, 0.36, 1];
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease } },
};
const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};

/* خلفية حيّة خفيفة (متناسقة مع الهيرو) */
function AboutAuroraBg() {
  return (
    <>
      <div
        className="absolute inset-0 -z-50"
        style={{ background: "linear-gradient(135deg,#ffffff 0%,#f8fbff 50%,#f0f7ff 100%)" }}
        aria-hidden
      />
      <motion.div
        className="absolute inset-0 -z-40 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(15,23,42,.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(15,23,42,.25) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          backgroundPosition: "0px 0px",
        }}
        animate={{ backgroundPosition: ["0px 0px", "28px 28px"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -top-28 -left-20 h-[24rem] w-[24rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(59,130,246,0.18), transparent 60%)" }}
        animate={{ x: [0, 18, -10, 0], y: [0, -12, 10, 0], scale: [1, 1.04, 0.98, 1] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -bottom-28 -right-24 h-[24rem] w-[24rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(56,189,248,0.16), transparent 60%)" }}
        animate={{ x: [0, -14, 12, 0], y: [0, 10, -10, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
    </>
  );
}

export default function About() {
  return (
    <section id="apropos" className="relative overflow-hidden py-16 md:py-20">
      <AboutAuroraBg />

      <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 md:grid-cols-2">
        {/* الصورة مع إطار فقاعي + ظل سفلي ناعم */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true }}
          className="relative"
        >
          <div className="relative">
            <motion.img
              src={ASSETS.about}
              alt="À propos"
              className="w-full rounded-[28px] object-cover shadow-[0_25px_60px_rgba(2,6,23,0.15)] ring-1 ring-slate-200"
              initial={{ rotate: -1, scale: 1.01 }}
              whileHover={{ rotate: 0, scale: 1.03 }}
              transition={{ duration: 0.6, ease }}
            />
            {/* ظل سفلي لطيف */}
            <div className="pointer-events-none absolute inset-x-8 bottom-3 h-10 rounded-full bg-gradient-to-r from-sky-200/45 via-blue-200/45 to-indigo-200/45 blur-2xl" />
          </div>

          {/* Phone badge تحت الصورة */}
          <PhoneBadge className="mt-3 w-fit" />

          {/* ستيكر بسيط يطفو */}
          <motion.span
            className="pointer-events-none absolute -right-2 -top-2 hidden rounded-full bg-white/80 px-3 py-1.5 text-xs font-semibold text-slate-700 ring-1 ring-slate-200 md:block"
            animate={{ y: [-8, 6, -8] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          >
            Technologies de pointe
          </motion.span>
        </motion.div>

        {/* النصوص مع عنوان وunderline متحرك */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
        >
          <motion.p variants={fadeUp} className="mb-2 text-sm font-semibold text-blue-700">
            À PROPOS
          </motion.p>

          <motion.h3
            variants={fadeUp}
            className="relative mb-4 text-4xl font-black leading-tight tracking-tight text-slate-900 md:text-5xl"
          >
            L’AUDITION <span className="text-blue-700">DE LA HALLE</span>
            <motion.span
              className="absolute -bottom-1 left-0 block h-2 w-40 rounded-full"
              style={{
                background:
                  "linear-gradient(90deg, rgba(37,99,235,1), rgba(56,189,248,1), rgba(99,102,241,1))",
              }}
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease }}
              aria-hidden
            />
          </motion.h3>

          <motion.p variants={fadeUp} className="mb-6 text-slate-700">
            Au cœur de <span className="font-semibold text-slate-900">Tarbes</span>, accompagnement
            <span className="font-semibold"> personnalisé</span> : du dépistage gratuit à l'appareillage
            avec <span className="font-semibold">essai d'un mois</span>, technologies miniaturisées et connectées,
            solutions <span className="font-semibold text-blue-700">100% santé</span>.
          </motion.p>

          <ul className="space-y-3 text-slate-700">
            <motion.li variants={fadeUp} className="flex items-start gap-2">
              <Check className="mt-1 h-5 w-5 text-blue-700" /> Technologies de pointe
            </motion.li>
            <motion.li variants={fadeUp} className="flex items-start gap-2">
              <Check className="mt-1 h-5 w-5 text-blue-700" /> Suivi personnalisé assuré par la même
              professionnelle
            </motion.li>
          </ul>

          <motion.div variants={fadeUp} className="mt-6">
            {/* زر حديث بخلفية متحركة مثل الهيرو/كونتاكت */}
            <motion.a
              whileHover={{ y: -1, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              href="#contact"
              className="no-underline inline-flex items-center justify-center rounded-2xl px-5 py-3 text-sm font-semibold text-white"
              style={{
                background: "linear-gradient(90deg,#2563eb,#38bdf8,#6366f1,#2563eb)",
                backgroundSize: "300% 300%",
                boxShadow:
                  "0 10px 25px rgba(37,99,235,0.25), inset 0 1px 0 rgba(255,255,255,.15)",
              }}
              animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
              transition={{ duration: 7, repeat: Infinity, ease: "linear" }}
            >
              PRENDRE RDV
            </motion.a>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
