// src/sections/Contact.jsx
import React from "react";
import { motion } from "framer-motion";
import { MapPin, Phone, Send } from "lucide-react";

const ASSETS = {
  contact: "/img/contact.jpg",
};

/* Variants */
const ease = [0.22, 1, 0.36, 1];
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease } },
};
const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
};

/* خلفية حيّة مشابهة للهيرو */
function ContactAuroraBg() {
  return (
    <>
      <div
        className="absolute inset-0 -z-50"
        style={{ background: "linear-gradient(135deg,#ffffff 0%,#f8fbff 50%,#f0f7ff 100%)" }}
        aria-hidden
      />
      <motion.div
        className="absolute inset-0 -z-40 opacity-[0.04]"
        style={{
          backgroundImage:
            "linear-gradient(to right, rgba(15,23,42,.25) 1px, transparent 1px), linear-gradient(to bottom, rgba(15,23,42,.25) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          backgroundPosition: "0px 0px",
        }}
        animate={{ backgroundPosition: ["0px 0px", "28px 28px"] }}
        transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -top-28 -right-24 h-[26rem] w-[26rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(59,130,246,0.18), transparent 60%)" }}
        animate={{ x: [0, -20, 12, 0], y: [0, 14, -10, 0], scale: [1, 1.04, 0.98, 1] }}
        transition={{ duration: 26, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
      <motion.div
        className="pointer-events-none absolute -bottom-28 -left-24 h-[26rem] w-[26rem] rounded-full blur-3xl"
        style={{ background: "radial-gradient(circle, rgba(56,189,248,0.16), transparent 60%)" }}
        animate={{ x: [0, 16, -12, 0], y: [0, -12, 10, 0] }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
        aria-hidden
      />
    </>
  );
}

export default function Contact() {
  return (
    <section id="contact" className="relative overflow-hidden py-16 md:py-20 text-slate-900">
      <ContactAuroraBg />

      <div className="relative mx-auto grid max-w-7xl grid-cols-1 items-center gap-10 px-4 md:grid-cols-2">
        {/* الفورم داخل كارت زجاجي */}
        <motion.div
          variants={stagger}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.3 }}
          className="relative rounded-3xl bg-white/70 p-6 ring-1 ring-slate-200 backdrop-blur-xl md:p-8"
        >
          {/* شارة الهاتف فوق العنوان مثل الهيرو */}
          <motion.a
            variants={fadeUp}
            href="tel:+33562365276"
            className="mb-3 inline-flex items-center gap-2 rounded-xl bg-indigo-600/10 px-3 py-2 text-sm font-semibold text-indigo-700 ring-1 ring-indigo-200 hover:bg-indigo-600/15"
            whileHover={{ y: -1 }}
          >
            <Phone className="h-4 w-4" />
            05 62 36 52 76
          </motion.a>

          {/* العنوان مع underline متحركة وكلمة ملوّنة */}
          <motion.h3
            variants={fadeUp}
            className="relative mb-3 text-4xl font-black leading-tight md:text-5xl"
          >
            NOUS <span className="text-blue-700">CONTACTER</span>
            <motion.span
              className="absolute -bottom-1 left-0 block h-2 w-40 rounded-full"
              style={{
                background:
                  "linear-gradient(90deg, rgba(37,99,235,1), rgba(56,189,248,1), rgba(99,102,241,1))",
              }}
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8, ease }}
              aria-hidden
            />
          </motion.h3>

          <motion.p variants={fadeUp} className="mb-6 max-w-xl text-slate-700">
            <span className="font-semibold text-slate-900">Consultation gratuite</span>, sans
            ordonnance. Remplissez le formulaire et on vous rappelle.
          </motion.p>

          <motion.form variants={fadeUp} onSubmit={(e) => e.preventDefault()} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <input
                className="w-full rounded-xl border border-slate-300 bg-white/70 px-3 py-2 outline-none ring-0 transition focus:border-blue-300 focus:ring-2 focus:ring-blue-600"
                placeholder="Votre nom"
              />
              <input
                type="email"
                className="w-full rounded-xl border border-slate-300 bg-white/70 px-3 py-2 outline-none ring-0 transition focus:border-blue-300 focus:ring-2 focus:ring-blue-600"
                placeholder="Votre e-mail"
              />
            </div>
            <input
              className="w-full rounded-xl border border-slate-300 bg-white/70 px-3 py-2 outline-none ring-0 transition focus:border-blue-300 focus:ring-2 focus:ring-blue-600"
              placeholder="Numéro de téléphone"
            />
            <textarea
              rows={5}
              className="w-full rounded-xl border border-slate-300 bg-white/70 px-3 py-2 outline-none ring-0 transition focus:border-blue-300 focus:ring-2 focus:ring-blue-600"
              placeholder="Votre demande"
            />

            {/* زر حديث بخلفية متحركة */}
            <motion.button
              whileHover={{ y: -1, scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="group relative inline-flex items-center gap-2 overflow-hidden rounded-2xl px-5 py-3 text-sm font-semibold text-white"
              style={{
                background:
                  "linear-gradient(90deg,#2563eb,#38bdf8,#6366f1,#2563eb)",
                backgroundSize: "300% 300%",
                boxShadow:
                  "0 10px 25px rgba(37,99,235,0.25), inset 0 1px 0 rgba(255,255,255,.15)",
              }}
              animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
              transition={{ duration: 7, repeat: Infinity, ease: "linear" }}
            >
              <Send className="h-4 w-4 opacity-90 transition-transform group-hover:-translate-y-[1px]" />
              ENVOYER
            </motion.button>
          </motion.form>

          {/* ستيكر صغير يطفو */}
          <motion.span
            className="pointer-events-none absolute -right-2 -top-2 hidden rounded-full bg-white/80 px-3 py-1.5 text-xs font-semibold text-slate-700 ring-1 ring-slate-200 md:block"
            animate={{ y: [-8, 6, -8] }}
            transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          >
            Sans ordonnance
          </motion.span>
        </motion.div>

        {/* الصورة + صندوق العنوان بنفس روح الهيرو */}
        <motion.div variants={fadeUp} initial="hidden" whileInView="show" viewport={{ once: true }}>
          <div className="relative">
            <motion.img
              src={ASSETS.contact}
              alt="Contact"
              className="w-full rounded-[28px] object-cover shadow-[0_25px_60px_rgba(2,6,23,0.15)] ring-1 ring-slate-200"
              initial={{ rotate: -1, scale: 1.02 }}
              whileHover={{ rotate: 0, scale: 1.04 }}
              transition={{ duration: 0.6, ease }}
            />
            {/* خط ظل ناعم أسفل الصورة */}
            <div className="pointer-events-none absolute inset-x-8 bottom-3 h-10 rounded-full bg-gradient-to-r from-sky-200/45 via-blue-200/45 to-indigo-200/45 blur-2xl" />
          </div>

          <motion.div
            initial={{ opacity: 0, y: -8 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease }}
            className="mt-4 w-fit rounded-2xl bg-white/90 p-4 shadow-xl ring-1 ring-slate-200"
          >
            <div className="flex items-center gap-3">
              <MapPin className="h-5 w-5 text-blue-700" />
              <div className="text-sm">
                <div className="font-semibold">13 rue François Mousis</div>
                <div className="text-slate-600">65000 Tarbes</div>
              </div>
            </div>
          </motion.div>

          {/* ستيكر آخر لطيف */}
          <motion.div
            className="pointer-events-none mt-3 hidden w-fit rounded-full bg-white/80 px-3 py-1.5 text-xs font-semibold text-slate-700 ring-1 ring-slate-200 md:block"
            animate={{ x: [0, 6, 0], y: [0, -4, 0] }}
            transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          >
            RDV rapide
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
